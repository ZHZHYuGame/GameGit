using System;
using UnityEditor;
using UnityEngine;
public interface IMonsterAI
{
    void Attack();
    void ChaseTarget();
}
public interface IMonsterFactory
{
    IMonsterAI CreateMonster();
}
public class ZombieAI : IMonsterAI
{
    public void Attack()
    {
        
    }

    public void ChaseTarget()
    {
        Console.WriteLine("Zombie is chasing the target.");
    }
}

public class VampireAI : IMonsterAI
{
    public void Attack()
    {
        Console.WriteLine("Vampire is attacking.");
    }

    public void ChaseTarget()
    {
        Console.WriteLine("Vampire is chasing the target.");
    }
}
public class ZombieFactory : IMonsterFactory
{
    public IMonsterAI CreateMonster()
    {
        return new ZombieAI();
    }
}

public class VampireFactory : IMonsterFactory
{
    public IMonsterAI CreateMonster()
    {
        return new VampireAI();
    }
}
public enum AIState 
{
    Idle, 
    Move, 
    Attack 
}
public class MonsterAI
{ 
    public IMonsterAI SpawnMonster(IMonsterFactory factory)
    {
        IMonsterAI monster = factory.CreateMonster();
        return monster;
    }
    AIState currentState = AIState.Idle;
    Animator anim;
    void UpdateAnimation(AIState ai)
    {
        switch (ai)
        {
            case AIState.Idle: anim.SetTrigger("Idle"); break;
            case AIState.Move: anim.SetTrigger("Move"); break;
            case AIState.Attack: anim.SetTrigger("Attack"); break;
        }
    }
}
public class EnemyTest:MonoBehaviour
{
    public void Show()
    {
        
    }
}