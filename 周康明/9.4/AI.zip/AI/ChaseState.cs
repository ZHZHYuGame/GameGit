using UnityEngine;
public class ChaseState : FSMState
{
    private Transform playerTrans;
    private float speed;

    public ChaseState(FSMSystem fsmSystem,float speed) : base(fsmSystem)
    {
        stateID = StateID.Chase;
        this.speed = speed;
        playerTrans = GameObject.Find("Player").transform;
    }

    // ׷��
    public override void Act(GameObject npc)
    {
        Vector2 direction = (new Vector2(playerTrans.position.x, playerTrans.position.y) - new Vector2(npc.transform.position.x, npc.transform.position.y)).normalized;
        npc.transform.Translate(direction * speed * Time.deltaTime);
    }

    // �л�
    public override void Reason(GameObject npc)
    {
        if (Vector2.Distance(playerTrans.position, npc.transform.position) > 3)
        {
            fsmSystem.PerformTransition(Transition.LostPlayer);
        }
    }
}