using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class PatrolState : FSMState
{
    private List<Vector2> path;
    private int index = 0;
    private Transform playerTrans;
    private float speed;
    public PatrolState(FSMSystem fsmSystem,float speed) : base(fsmSystem)
    {
        stateID = StateID.Patrol;
        GetRandowPathList();
        this.speed = speed;
        playerTrans = GameObject.Find("Player").transform;
    }
    // ���·����
    private void GetRandowPathList()
    {
        path = new List <Vector2>();
        for (int i = 0; i < 8; i++)
        {
            int x = Random.Range(-10, 10);
            int y = Random.Range(-10, 10);
            Vector2 randomPoint = new Vector2(x, y);
            path.Add(randomPoint);
        }
    }
    // Ѳ��
    public override void Act(GameObject npc)
    {
        Vector2 targetPosition = path[index];
        Vector2 direction = (targetPosition - new Vector2(npc.transform.position.x, npc.transform.position.y)).normalized;
        npc.transform.Translate(direction * speed*Time.deltaTime);
        if (Vector2.Distance(npc.transform.position, path[index])<1)
        {
            index++;
            index %= path.Count;
        }
    }
    // �л�
    public override void Reason(GameObject npc)
    {
        if(Vector2.Distance(playerTrans.position,npc.transform.position)<3)
        {
            fsmSystem.PerformTransition(Transition.SeePlayer);
        }
    }
}
